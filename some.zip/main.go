// main
package main

import (
	"strconv"
	"sync"
	"time"
	"fmt"
)


func main(){
	
	
	
	for{
		select{
			
		}
	}
	
}

func main2() {
	fmt.Println("Hello World!")
	
	rawmsgs:=make([]string,100)
	
	var wg sync.WaitGroup
	
	current:=make(chan bool, 12)
	
	for i,_:=range rawmsgs {
		
		current<-true
		wg.Add(1)
		go func(wg *sync.WaitGroup, msg string){
			defer wg.Done()
			
			fakeRequest(msg)
			<-current
		}(&wg,"hey"+strconv.Itoa(i))
		
	}
	
	
	wg.Wait()
		
	
}

func fakeRequest(msg string){
	
	time.Sleep(2000*time.Millisecond)
	fmt.Println(msg)
	
}
